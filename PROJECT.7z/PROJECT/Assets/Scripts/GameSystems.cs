﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameSystems : MonoBehaviour
{
    public void Init()
    {

    }

    public void Terminate()
    {

    }

    #region private



    #endregion
}
