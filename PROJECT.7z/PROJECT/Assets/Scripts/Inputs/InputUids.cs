﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum InputUid
{
    NONE,
    ATTACK,
    BLOCK,
    SLOT_1,
    SLOT_2,
    SLOT_3,
    SLOT_ABILITY_1,
    SLOT_ABILITY_2,
    SWAP_WEAPON
}

public class InputUids : MonoBehaviour
{

	
}
